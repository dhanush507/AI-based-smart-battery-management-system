import pytest
from battery_lab.data import make_demo_data,validate_data
from battery_lab.features import build_features
from battery_lab.splitting import group_split
def test_clean_and_labels():
 d=build_features(make_demo_data(8,220));assert d.soh_percent.notna().all();assert d.rul_cycles.notna().any()
def test_required_schema():
 with pytest.raises(ValueError):validate_data(make_demo_data().drop(columns="temperature_mean_c"))
def test_split_by_cell():
 d=build_features(make_demo_data(8,50));_,_,a,b=group_split(d);assert set(a).isdisjoint(b)
