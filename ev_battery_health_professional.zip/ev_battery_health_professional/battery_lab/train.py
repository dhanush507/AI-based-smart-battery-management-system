from pathlib import Path
import json,joblib,yaml,pandas as pd
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from .features import build_features,feature_names
from .splitting import group_split
from .models import candidates
def metrics(y,p):return {"MAE":float(mean_absolute_error(y,p)),"RMSE":float(mean_squared_error(y,p)**.5),"R2":float(r2_score(y,p)) if len(y)>1 else None}
def train(data_path,out="artifacts",config="config.yaml"):
    cfg=yaml.safe_load(Path(config).read_text()) if Path(config).exists() else {}
    d=build_features(pd.read_csv(data_path),cfg.get("eol_soh_percent",80));features=feature_names(d)
    tr,te,train_cells,test_cells=group_split(d,cfg.get("test_size",.25),cfg.get("random_state",42));bank=candidates(cfg.get("random_state",42),cfg.get("models",{}));fitted={};report={}
    for target in ["soh_percent","rul_cycles"]:
        valid=d[target].notna();itr=[i for i in tr if valid.iloc[i]];ite=[i for i in te if valid.iloc[i]]
        if len(itr)<10 or len(ite)<3:report[target]={"status":"skipped","reason":"Not enough labeled train/test records"};continue
        scores={}
        for name,m in bank.items():
            m.fit(d.iloc[itr][features],d.iloc[itr][target]);scores[name]=metrics(d.iloc[ite][target],m.predict(d.iloc[ite][features]))
        winner=min(scores,key=lambda k:scores[k]["MAE"]);fitted[target]={"name":winner,"pipeline":bank[winner]}
        report[target]={"selected":winner,"candidate_metrics":scores,"holdout_rows":len(ite)}
    if not fitted:raise RuntimeError("No model trained; need more cells and observed EOL crossings for RUL")
    bundle={"models":fitted,"features":features,"eol_soh_percent":cfg.get("eol_soh_percent",80),"report":report,"train_cells":train_cells,"test_cells":test_cells}
    p=Path(out);p.mkdir(parents=True,exist_ok=True);joblib.dump(bundle,p/"model_bundle.joblib")
    (p/"evaluation.json").write_text(json.dumps(report,indent=2));(p/"split.json").write_text(json.dumps({"train":train_cells,"test":test_cells},indent=2));return report
def evaluate(data_path,model_path):
    b=joblib.load(model_path);d=build_features(pd.read_csv(data_path),b["eol_soh_percent"]);d=d[d.cell_id.isin(b["test_cells"])];out={}
    for target,m in b["models"].items():
        mask=d[target].notna()
        if mask.any():out[target]=metrics(d.loc[mask,target],m["pipeline"].predict(d.loc[mask,b["features"]]))
    return out
