from pathlib import Path
import numpy as np
import pandas as pd
REQUIRED=["cell_id","cycle","capacity_ah","nominal_capacity_ah","voltage_mean_v","current_mean_a","temperature_mean_c"]
OPTIONAL=["charge_time_min","discharge_time_min","internal_resistance_mohm"]
def validate_data(df):
    missing=sorted(set(REQUIRED)-set(df.columns))
    if missing: raise ValueError(f"Missing required columns: {missing}")
    d=df.copy();d.cell_id=d.cell_id.astype(str).str.strip()
    for c in REQUIRED[1:]+[x for x in OPTIONAL if x in d]:
        d[c]=pd.to_numeric(d[c],errors="coerce")
    d=d.dropna(subset=REQUIRED[1:])
    d=d[(d.cycle>=0)&(d.capacity_ah>0)&(d.nominal_capacity_ah>0)]
    d=d.drop_duplicates(["cell_id","cycle"],keep="last").sort_values(["cell_id","cycle"])
    if d.empty: raise ValueError("No valid rows after cleaning")
    return d.reset_index(drop=True)
def load_csv(path): return validate_data(pd.read_csv(path))
def make_demo_data(n_cells=30,n_cycles=220,seed=7):
    if n_cells<4 or n_cycles<20: raise ValueError("Need >=4 cells and >=20 cycles")
    r=np.random.default_rng(seed);rows=[]
    for i in range(n_cells):
        nominal=r.uniform(1.7,3.4);rate=r.uniform(.0007,.0019);knee=r.uniform(.48,.82)*n_cycles;offset=r.normal(0,1)
        for c in range(1,n_cycles+1):
            soh=max(52,100-100*(rate*c+.000012*max(0,c-knee)**1.35))
            cap=max(.05,nominal*soh/100+r.normal(0,nominal*.0025))
            rows.append(dict(cell_id=f"CELL_{i+1:03}",cycle=c,capacity_ah=cap,nominal_capacity_ah=nominal,
             voltage_mean_v=3.78-.0008*c+r.normal(0,.018),current_mean_a=max(.1,1.05+.001*c+r.normal(0,.07)),
             temperature_mean_c=25+offset+.012*c+r.normal(0,.9),charge_time_min=max(1,44+.055*c+r.normal(0,1.8)),
             discharge_time_min=max(1,55*cap/nominal+r.normal(0,1.2)),internal_resistance_mohm=max(1,28+.10*c+r.normal(0,1.8))))
    return pd.DataFrame(rows)
def write_demo(path,n_cells=30,n_cycles=220,seed=7):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);make_demo_data(n_cells,n_cycles,seed).to_csv(p,index=False);return p
