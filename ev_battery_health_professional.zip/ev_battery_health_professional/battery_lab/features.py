from .data import validate_data
FEATURES=["cycle","capacity_ah","nominal_capacity_ah","voltage_mean_v","current_mean_a","temperature_mean_c","capacity_ratio","capacity_delta_rolling","temperature_delta_rolling","charge_time_min","discharge_time_min","internal_resistance_mohm"]
def build_features(frame,eol_soh=80):
    if not 50<=eol_soh<=95:raise ValueError("EOL threshold must be 50–95")
    d=validate_data(frame);d["soh_percent"]=100*d.capacity_ah/d.nominal_capacity_ah;d["capacity_ratio"]=d.capacity_ah/d.nominal_capacity_ah
    d["capacity_delta_rolling"]=d.groupby("cell_id").capacity_ah.transform(lambda s:s.diff().rolling(5,min_periods=1).mean()).fillna(0)
    d["temperature_delta_rolling"]=d.groupby("cell_id").temperature_mean_c.transform(lambda s:s.diff().rolling(5,min_periods=1).mean()).fillna(0)
    for c in ["charge_time_min","discharge_time_min","internal_resistance_mohm"]:
        if c not in d:d[c]=float("nan")
    d["rul_cycles"]=float("nan")
    for _,ix in d.groupby("cell_id").groups.items():
        g=d.loc[ix];cross=g.loc[g.soh_percent<=eol_soh,"cycle"]
        if len(cross):d.loc[ix,"rul_cycles"]=(float(cross.iloc[0])-g.cycle).clip(lower=0).to_numpy()
    return d
def feature_names(d):return [x for x in FEATURES if x in d]
