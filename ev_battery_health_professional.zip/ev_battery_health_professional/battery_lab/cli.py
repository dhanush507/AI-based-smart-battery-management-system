import argparse,json
from .data import write_demo,load_csv
from .train import train,evaluate
def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest="cmd",required=True)
 a=s.add_parser("make-demo");a.add_argument("--out",default="data/demo.csv");a.add_argument("--batteries",type=int,default=30);a.add_argument("--cycles",type=int,default=220)
 b=s.add_parser("validate");b.add_argument("--data",required=True)
 c=s.add_parser("train");c.add_argument("--data",required=True);c.add_argument("--out",default="artifacts");c.add_argument("--config",default="config.yaml")
 d=s.add_parser("evaluate");d.add_argument("--data",required=True);d.add_argument("--model",default="artifacts/model_bundle.joblib")
 x=p.parse_args()
 if x.cmd=="make-demo":print(write_demo(x.out,x.batteries,x.cycles))
 elif x.cmd=="validate":print(f"Valid: {len(load_csv(x.data))} rows")
 elif x.cmd=="train":print(json.dumps(train(x.data,x.out,x.config),indent=2))
 elif x.cmd=="evaluate":print(json.dumps(evaluate(x.data,x.model),indent=2))
if __name__=="__main__":main()
