from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor,HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
def candidates(seed=42,cfg=None):
    cfg=cfg or {};rf=cfg.get("random_forest",{});et=cfg.get("extra_trees",{})
    def pipe(m):return Pipeline([("imputer",SimpleImputer(strategy="median")),("regressor",m)])
    return {"random_forest":pipe(RandomForestRegressor(n_estimators=rf.get("n_estimators",200),min_samples_leaf=rf.get("min_samples_leaf",2),random_state=seed,n_jobs=-1)),
    "extra_trees":pipe(ExtraTreesRegressor(n_estimators=et.get("n_estimators",200),min_samples_leaf=et.get("min_samples_leaf",2),random_state=seed,n_jobs=-1)),
    "hist_gradient_boosting":pipe(HistGradientBoostingRegressor(max_iter=120,learning_rate=.08,l2_regularization=1,random_state=seed))}
