from sklearn.model_selection import GroupShuffleSplit
def group_split(d,test_size=.25,seed=42):
    if d.cell_id.nunique()<4:raise ValueError("Need >=4 cells for group holdout")
    tr,te=next(GroupShuffleSplit(n_splits=1,test_size=test_size,random_state=seed).split(d,groups=d.cell_id))
    a=set(d.cell_id.iloc[tr]);b=set(d.cell_id.iloc[te]);assert a.isdisjoint(b)
    return tr,te,sorted(a),sorted(b)
