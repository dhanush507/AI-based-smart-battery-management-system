from pathlib import Path
import joblib
from .features import build_features
def load_bundle(path="artifacts/model_bundle.joblib"):
    if not Path(path).exists():raise FileNotFoundError("Train first; model bundle is missing")
    return joblib.load(path)
def predict(df,b):
    d=build_features(df,b["eol_soh_percent"]);x=d.reindex(columns=b["features"]);o=d[["cell_id","cycle","soh_percent"]].copy()
    for target,col in [("soh_percent","estimated_soh_percent"),("rul_cycles","estimated_rul_cycles")]:
        if target in b["models"]:o[col]=b["models"][target]["pipeline"].predict(x).clip(0,120 if target=="soh_percent" else None)
    return o
