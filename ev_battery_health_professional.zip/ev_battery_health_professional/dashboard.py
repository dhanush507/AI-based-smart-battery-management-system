from pathlib import Path
import pandas as pd,streamlit as st,matplotlib.pyplot as plt
from battery_lab.data import make_demo_data,validate_data
from battery_lab.features import build_features
from battery_lab.train import train
from battery_lab.inference import load_bundle,predict
st.set_page_config(page_title="EV Battery Health",page_icon="🔋",layout="wide")
st.title("🔋 EV Battery SOH / RUL Analytics")
st.caption("Research/portfolio prototype. Synthetic demo is not real battery evidence.")
with st.sidebar:
 f=st.file_uploader("Upload CSV (README schema)",type=["csv"]);demo=st.checkbox("Use demo data",value=f is None)
try:d0=validate_data(pd.read_csv(f) if f is not None and not demo else make_demo_data())
except Exception as e:st.error(str(e));st.stop()
eol=st.slider("EOL threshold SOH (%)",50,95,80);d=build_features(d0,eol)
x,y,z=st.columns(3);x.metric("Cells",d.cell_id.nunique());y.metric("Rows",len(d));z.metric("Median SOH",f"{d.soh_percent.median():.1f}%")
with st.expander("Data preview"):
 st.dataframe(d.head(200),use_container_width=True);st.download_button("Download processed CSV",d.to_csv(index=False).encode(),"processed.csv","text/csv")
fig,ax=plt.subplots()
for _,g in d.groupby("cell_id"):ax.plot(g.cycle,g.soh_percent,alpha=.3)
ax.axhline(eol,ls="--",label=f"EOL {eol}%");ax.set(xlabel="Cycle",ylabel="SOH (%)");ax.legend();st.pyplot(fig);plt.close(fig)
if st.button("Train and compare",type="primary"):
 Path("data").mkdir(exist_ok=True);d.to_csv("data/dashboard_data.csv",index=False)
 try:
  with st.spinner("Training / evaluating cell-held-out models"):r=train("data/dashboard_data.csv")
  st.success("Training finished");st.json(r)
 except Exception as e:st.error(str(e))
if Path("artifacts/model_bundle.joblib").exists():
 try:
  b=load_bundle();cell=st.selectbox("Choose cell",sorted(d.cell_id.unique()));p=predict(d[d.cell_id==cell],b)
  last=p.iloc[-1];cols=st.columns(2)
  if "estimated_soh_percent" in p:cols[0].metric("Estimated SOH",f"{last.estimated_soh_percent:.1f}%")
  if "estimated_rul_cycles" in p:cols[1].metric("Estimated RUL",f"{last.estimated_rul_cycles:.0f} cycles")
  st.dataframe(p.tail(40));st.download_button("Download predictions",p.to_csv(index=False).encode(),f"{cell}_predictions.csv","text/csv");st.json(b["report"])
 except Exception as e:st.warning(str(e))
else:st.info("Train models to enable predictions.")
st.warning("Never use these predictions to control a real battery or make safety-critical decisions.")
