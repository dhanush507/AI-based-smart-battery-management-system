# EV Battery Health Analytics (SOH/RUL)
Professional portfolio/research prototype with data validation, features, cell-group evaluation, three ML candidates, CLI, Streamlit dashboard, tests, and methodology/model-card documentation.

**Caution:** synthetic demo data is illustrative, not a physical battery simulator. This is not a certified BMS and must not be used for safety, charging, warranty, or maintenance decisions. Real-world validity requires a properly mapped, documented real dataset and external validation.

## Quickstart (Python 3.10–3.12)
```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m battery_lab.cli make-demo --out data/demo.csv --batteries 30 --cycles 220
python -m battery_lab.cli validate --data data/demo.csv
python -m battery_lab.cli train --data data/demo.csv --out artifacts
python -m battery_lab.cli evaluate --data data/demo.csv --model artifacts/model_bundle.joblib
streamlit run dashboard.py
pytest
```
## CSV schema
Required: `cell_id, cycle, capacity_ah, nominal_capacity_ah, voltage_mean_v, current_mean_a, temperature_mean_c`. Optional: `charge_time_min, discharge_time_min, internal_resistance_mohm`. SOH=100×capacity/reference capacity. RUL is retrospectively labeled as cycles until the first observed crossing of EOL SOH (default 80%); cells that do not cross have unknown RUL.

NASA PCoE/CALCE data formats vary by experiment. `docs/REAL_DATA_ADAPTER.md` explains how to inspect, map, and document a specific dataset; the project does not pretend to auto-parse arbitrary raw files.

## Contents
`battery_lab/` ingestion, feature engineering, group splitting, model candidates, training, inference, CLI. `dashboard.py` interactive UI. `tests/` unit/split tests. `docs/` methodology, real-data mapping checklist, model card, report template.

Metrics use a held-out set of cell IDs, not random rows. Candidate selection on that holdout can be optimistic; use grouped CV and an untouched external test for rigorous claims. Never report synthetic demo scores as real validation.
