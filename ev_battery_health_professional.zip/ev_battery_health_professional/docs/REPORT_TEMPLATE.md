# Report template
1. Abstract / research question
2. Dataset provenance, license, chemistry, protocol, units, cells
3. SOH/RUL definitions and EOL threshold
4. Preprocessing and feature engineering
5. Group split and model configurations
6. MAE/RMSE/R², per-cell error analysis
7. Limitations, distribution shift, next experiments
8. Reproducibility: environment, seeds, commit
